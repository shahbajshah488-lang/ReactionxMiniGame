export type GameMode = 'classic' | 'five_rounds' | 'endurance' | 'daily';

export type GamePhase = 
  | 'IDLE'
  | 'COUNTDOWN'
  | 'WAITING'       // Red screen: WAIT FOR GREEN
  | 'READY'         // Green screen: CLICK NOW!
  | 'FALSE_START'   // Red warning: TOO EARLY!
  | 'ROUND_RESULT'  // Intermediate result in multi-round modes
  | 'GAME_OVER';    // Final results screen

export interface AttemptRecord {
  round: number;
  timeMs: number;
  falseStarts: number;
}

export interface GameResult {
  id: string;
  mode: GameMode;
  timestamp: number;
  attempts: number[];
  averageMs: number;
  fastestMs: number;
  slowestMs: number;
  falseStarts: number;
  rating: string;
  ratingColor: string;
  isNewPersonalBest?: boolean;
}

export interface PerformanceRating {
  tier: string;
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  description: string;
  percentile: string;
}

export interface UserStats {
  nickname: string;
  classicBest: number | null;
  fiveRoundsBestAvg: number | null;
  enduranceBestAvg: number | null;
  dailyStreak: number;
  lastDailyDate: string | null;
  dailyCompletedToday: boolean;
  totalGamesPlayed: number;
  totalFalseStarts: number;
  unlockedAchievements: string[];
  history: GameResult[];
  soundEnabled: boolean;
  hapticsEnabled: boolean;
}

export interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  timeMs: number;
  mode: GameMode;
  tag: string;
  isUser?: boolean;
  date: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
}
