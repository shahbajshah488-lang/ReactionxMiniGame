import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { GameMode, GameResult, UserStats } from './types/game';
import { 
  loadUserStats, 
  saveUserStats, 
  saveGameResult, 
  getDailyTarget, 
  setSavedNickname 
} from './utils/storage';
import { Header } from './components/Header';
import { StartScreen } from './components/StartScreen';
import { GameArena } from './components/GameArena';
import { ResultsDashboard } from './components/ResultsDashboard';
import { LeaderboardModal } from './components/LeaderboardModal';
import { InstructionsModal } from './components/InstructionsModal';
import { ShareModal } from './components/ShareModal';
import { generateWhatsAppShareText } from './utils/shareCard';
import { getPerformanceRating } from './utils/ratings';

export default function App() {
  const [stats, setStats] = useState<UserStats>(loadUserStats);
  const [currentMode, setCurrentMode] = useState<GameMode>('classic');
  const [screen, setScreen] = useState<'START' | 'ARENA' | 'RESULTS'>('START');
  
  // Active game result
  const [currentResult, setCurrentResult] = useState<GameResult | null>(null);
  const [isNewBest, setIsNewBest] = useState(false);
  const [newlyUnlocked, setNewlyUnlocked] = useState<string[]>([]);

  // Modals
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isInstructionsOpen, setIsInstructionsOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Incoming challenge data from URL query params
  const [challengerData, setChallengerData] = useState<{ score: number; name: string; mode: GameMode } | null>(null);

  // Daily target
  const dailyGoal = useMemo(() => getDailyTarget(), []);

  // Check URL parameters on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const scoreParam = searchParams.get('challenger');
      const nameParam = searchParams.get('name');
      const modeParam = searchParams.get('mode') as GameMode;

      if (scoreParam && !isNaN(Number(scoreParam))) {
        setChallengerData({
          score: Number(scoreParam),
          name: nameParam || 'A Challenger',
          mode: modeParam && ['classic', 'five_rounds', 'endurance', 'daily'].includes(modeParam) 
            ? modeParam 
            : 'classic',
        });
      }
    }
  }, []);

  // Sound toggle
  const handleToggleSound = useCallback(() => {
    setStats((prev) => {
      const updated = { ...prev, soundEnabled: !prev.soundEnabled };
      saveUserStats(updated);
      return updated;
    });
  }, []);

  // Haptics toggle
  const handleToggleHaptics = useCallback(() => {
    setStats((prev) => {
      const updated = { ...prev, hapticsEnabled: !prev.hapticsEnabled };
      saveUserStats(updated);
      return updated;
    });
  }, []);

  // Update Nickname
  const handleUpdateNickname = useCallback((newNick: string) => {
    setSavedNickname(newNick);
    setStats((prev) => {
      const updated = { ...prev, nickname: newNick };
      saveUserStats(updated);
      return updated;
    });
  }, []);

  // Start game in chosen mode
  const handleSelectMode = (mode: GameMode) => {
    setCurrentMode(mode);
    setScreen('ARENA');
  };

  // Game completed handler from GameArena
  const handleGameComplete = (attempts: number[], falseStarts: number) => {
    const validAttempts = attempts.filter((t) => t > 0);
    const mainScore = currentMode === 'classic' 
      ? (validAttempts[0] || 0)
      : Math.round(validAttempts.reduce((a, b) => a + b, 0) / (validAttempts.length || 1));
    
    const ratingObj = getPerformanceRating(mainScore);

    const { result, isNewBest: newBestAchieved, newlyUnlockedAchievements } = saveGameResult(
      currentMode,
      attempts,
      falseStarts,
      ratingObj.label,
      ratingObj.color
    );

    setCurrentResult(result);
    setIsNewBest(newBestAchieved);
    setNewlyUnlocked(newlyUnlockedAchievements);
    setStats(loadUserStats());
    setScreen('RESULTS');
  };

  // Play again in current mode
  const handlePlayAgain = () => {
    setScreen('ARENA');
  };

  // Go to main menu
  const handleGoHome = () => {
    setScreen('START');
  };

  // WhatsApp Share
  const handleShareWhatsApp = () => {
    if (!currentResult) return;
    const text = generateWhatsAppShareText(currentResult, stats.nickname);
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Copy challenge link to clipboard
  const handleChallengeFriend = () => {
    if (!currentResult) return;
    const mainScore = currentResult.mode === 'classic' ? currentResult.fastestMs : currentResult.averageMs;
    const url = `${window.location.origin}?challenger=${mainScore}&name=${encodeURIComponent(stats.nickname)}&mode=${currentResult.mode}`;
    navigator.clipboard.writeText(url);
  };

  // Open Score Card for Personal Best from Start Screen
  const handleOpenBestScoreCard = () => {
    const bestFromHistory = stats.history.find(h => h.mode === 'classic' && h.fastestMs === stats.classicBest) 
      || stats.history[0];
    
    if (bestFromHistory) {
      setCurrentResult(bestFromHistory);
      setIsShareModalOpen(true);
    } else if (stats.classicBest) {
      const ratingObj = getPerformanceRating(stats.classicBest);
      const mockResult: GameResult = {
        id: 'pb_' + Date.now(),
        mode: 'classic',
        timestamp: Date.now(),
        attempts: [stats.classicBest],
        averageMs: stats.classicBest,
        fastestMs: stats.classicBest,
        slowestMs: stats.classicBest,
        falseStarts: 0,
        rating: ratingObj.label,
        ratingColor: ratingObj.color,
        isNewPersonalBest: true,
      };
      setCurrentResult(mockResult);
      setIsShareModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#050508] text-white flex flex-col justify-between selection:bg-emerald-500 selection:text-black font-sans cyber-grid">
      {/* Top Header */}
      <Header
        currentPhase={screen === 'START' ? 'IDLE' : screen === 'ARENA' ? 'WAITING' : 'ROUND_RESULT'}
        soundEnabled={stats.soundEnabled}
        hapticsEnabled={stats.hapticsEnabled}
        onToggleSound={handleToggleSound}
        onToggleHaptics={handleToggleHaptics}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        onOpenInstructions={() => setIsInstructionsOpen(true)}
        onGoHome={handleGoHome}
      />

      {/* Main View Area */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-2 sm:px-4 flex flex-col justify-center items-center py-2 sm:py-4">
        {screen === 'START' && (
          <StartScreen
            stats={stats}
            dailyGoal={dailyGoal}
            challengerData={challengerData}
            onSelectMode={handleSelectMode}
            onClearChallenge={() => setChallengerData(null)}
            onOpenBestScoreCard={handleOpenBestScoreCard}
          />
        )}

        {screen === 'ARENA' && (
          <GameArena
            mode={currentMode}
            soundEnabled={stats.soundEnabled}
            hapticsEnabled={stats.hapticsEnabled}
            onGameComplete={handleGameComplete}
            onExitGame={handleGoHome}
          />
        )}

        {screen === 'RESULTS' && currentResult && (
          <ResultsDashboard
            result={currentResult}
            stats={stats}
            isNewPersonalBest={isNewBest}
            newAchievements={newlyUnlocked}
            onPlayAgain={handlePlayAgain}
            onGoHome={handleGoHome}
            onOpenScoreCardModal={() => setIsShareModalOpen(true)}
            onShareWhatsApp={handleShareWhatsApp}
            onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
            onChallengeFriend={handleChallengeFriend}
          />
        )}
      </main>

      {/* Leaderboard & Achievements Modal */}
      <LeaderboardModal
        stats={stats}
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        onUpdateNickname={handleUpdateNickname}
      />

      {/* Instructions & Reflex Science Modal */}
      <InstructionsModal
        isOpen={isInstructionsOpen}
        onClose={() => setIsInstructionsOpen(false)}
      />

      {/* Score Card & Sharing Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        result={currentResult}
        nickname={stats.nickname}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Subtle bottom footer copyright */}
      <footer className="w-full py-3 text-center text-[11px] text-neutral-400 font-mono">
        REACTION X · Human Reflex Challenge · High-Precision Sub-Millisecond Clock
      </footer>
    </div>
  );
}
