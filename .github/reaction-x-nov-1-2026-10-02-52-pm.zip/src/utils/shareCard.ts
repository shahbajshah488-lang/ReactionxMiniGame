import { GameResult } from '../types/game';
import { getPerformanceRating } from './ratings';

export async function generateScoreCardBlob(
  result: GameResult,
  nickname: string
): Promise<Blob | null> {
  const canvas = document.createElement('canvas');
  canvas.width = 1200;
  canvas.height = 630;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const rating = getPerformanceRating(result.mode === 'classic' ? result.fastestMs : result.averageMs);
  const mainScore = result.mode === 'classic' ? result.fastestMs : result.averageMs;

  // Background
  ctx.fillStyle = '#06070b';
  ctx.fillRect(0, 0, 1200, 630);

  // Radial ambient glow
  const gradient = ctx.createRadialGradient(600, 315, 50, 600, 315, 600);
  gradient.addColorStop(0, `${rating.color}25`);
  gradient.addColorStop(0.5, 'rgba(168, 85, 247, 0.08)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 1200, 630);

  // Subtle grid lines
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1;
  for (let x = 0; x < 1200; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 630);
    ctx.stroke();
  }
  for (let y = 0; y < 630; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(1200, y);
    ctx.stroke();
  }

  // Border card framing
  ctx.strokeStyle = rating.color;
  ctx.lineWidth = 3;
  ctx.shadowColor = rating.color;
  ctx.shadowBlur = 20;
  ctx.strokeRect(30, 30, 1140, 570);
  ctx.shadowBlur = 0;

  // Top header: Brand name
  ctx.fillStyle = '#ffffff';
  ctx.font = '900 38px "Outfit", sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('REACTION', 70, 95);

  const reactWidth = ctx.measureText('REACTION').width;
  ctx.fillStyle = rating.color;
  ctx.fillText(' X', 70 + reactWidth, 95);

  // Mode badge
  const modeText = result.mode === 'classic' 
    ? 'CLASSIC SINGLE TEST' 
    : result.mode === 'five_rounds' 
    ? '5-ROUND CHALLENGE' 
    : result.mode === 'endurance' 
    ? '10-ROUND ENDURANCE' 
    : 'DAILY CHALLENGE';

  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.font = '600 16px "JetBrains Mono", monospace';
  ctx.textAlign = 'right';
  ctx.fillText(modeText, 1130, 90);

  // Player Name & Date
  ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
  ctx.font = '500 15px "JetBrains Mono", monospace';
  ctx.fillText(`PILOT: ${nickname.toUpperCase()} · ${new Date(result.timestamp).toLocaleDateString()}`, 1130, 115);

  // Main Reflex Score Box
  ctx.textAlign = 'center';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.font = '700 18px "JetBrains Mono", monospace';
  ctx.fillText(result.mode === 'classic' ? 'REACTION TIME' : 'AVERAGE SPEED', 600, 200);

  // Giant Score
  ctx.fillStyle = '#ffffff';
  ctx.font = '900 135px "Outfit", sans-serif';
  ctx.shadowColor = rating.color;
  ctx.shadowBlur = 25;
  ctx.fillText(`${mainScore}`, 540, 330);
  ctx.shadowBlur = 0;

  // MS Unit
  ctx.fillStyle = rating.color;
  ctx.font = '800 48px "JetBrains Mono", monospace';
  ctx.fillText('MS', 730, 320);

  // Rating badge box
  const tierWidth = 340;
  const tierHeight = 50;
  const tierX = 600 - tierWidth / 2;
  const tierY = 370;

  ctx.fillStyle = `${rating.color}20`;
  ctx.beginPath();
  ctx.roundRect(tierX, tierY, tierWidth, tierHeight, 8);
  ctx.fill();

  ctx.strokeStyle = rating.color;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = rating.color;
  ctx.font = '800 22px "Outfit", sans-serif';
  ctx.fillText(`${rating.label.toUpperCase()} · ${rating.percentile}`, 600, tierY + 33);

  // Stats Grid in bottom area
  const statsY = 475;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.beginPath();
  ctx.roundRect(70, statsY, 1060, 80, 8);
  ctx.fill();

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.lineWidth = 1;
  ctx.stroke();

  // 3 Stat Columns
  const cols = [
    { label: 'FASTEST ROUND', value: `${result.fastestMs} ms` },
    { label: 'ATTEMPTS', value: `${result.attempts.length} rounds` },
    { label: 'FALSE STARTS', value: `${result.falseStarts}` },
  ];

  cols.forEach((col, idx) => {
    const colX = 70 + (1060 / 3) * idx + 1060 / 6;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '600 13px "JetBrains Mono", monospace';
    ctx.fillText(col.label, colX, statsY + 30);

    ctx.fillStyle = '#ffffff';
    ctx.font = '700 22px "JetBrains Mono", monospace';
    ctx.fillText(col.value, colX, statsY + 60);
  });

  // Footer challenge text
  ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
  ctx.font = '500 14px "JetBrains Mono", monospace';
  ctx.fillText('CHALLENGE YOUR REFLEXES AT REACTION X', 600, 588);

  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), 'image/png');
  });
}

export function downloadScoreCard(blob: Blob, scoreMs: number) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `reaction_x_score_${scoreMs}ms.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function downloadResultScoreCard(result: GameResult, nickname: string): Promise<boolean> {
  try {
    const blob = await generateScoreCardBlob(result, nickname);
    if (!blob) return false;
    const mainScore = result.mode === 'classic' ? result.fastestMs : result.averageMs;
    downloadScoreCard(blob, mainScore);
    return true;
  } catch {
    return false;
  }
}

export function downloadHistoryCSV(history: GameResult[], nickname: string): boolean {
  try {
    if (!history || history.length === 0) return false;
    const headers = ['Attempt ID', 'Date & Time', 'Game Mode', 'Round Scores (ms)', 'Average (ms)', 'Fastest (ms)', 'Slowest (ms)', 'False Starts', 'Rating'];
    const rows = history.map((h) => [
      h.id,
      new Date(h.timestamp).toLocaleString(),
      h.mode,
      h.attempts.join('; '),
      h.averageMs,
      h.fastestMs,
      h.slowestMs,
      h.falseStarts,
      h.rating
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.map(val => `"${val}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reaction_x_telemetry_${nickname.toLowerCase()}_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return true;
  } catch {
    return false;
  }
}

export function generateWhatsAppShareText(result: GameResult, nickname: string): string {
  const mainScore = result.mode === 'classic' ? result.fastestMs : result.averageMs;
  const rating = getPerformanceRating(mainScore);
  const modeName = result.mode === 'classic' ? 'Classic Mode' : result.mode === 'five_rounds' ? '5-Round Challenge' : 'Endurance Mode';

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}?challenger=${mainScore}&name=${encodeURIComponent(nickname)}&mode=${result.mode}`
    : '';

  return `⚡ I just scored *${mainScore}ms* (${rating.label}) in REACTION X - ${modeName}!\n\nCan you beat my human reflex speed? Challenge accepted: ${shareUrl}`;
}

