import { GameMode, GameResult, LeaderboardEntry, UserStats, Achievement } from '../types/game';

const STORAGE_KEY = 'reaction_x_user_stats';
const NICKNAME_KEY = 'reaction_x_nickname';

export const ALL_ACHIEVEMENTS: Omit<Achievement, 'unlocked'>[] = [
  {
    id: 'first_blood',
    title: 'First Reflex',
    description: 'Complete your first reaction test round.',
    icon: '⚡'
  },
  {
    id: 'sub_250',
    title: 'Speed Demon',
    description: 'Score under 250ms in any mode.',
    icon: '🔥'
  },
  {
    id: 'sub_200',
    title: 'Sub-200 Club',
    description: 'Break the 200ms barrier. Elite esports tier!',
    icon: '🏆'
  },
  {
    id: 'incredible_reflex',
    title: 'Incredible Reflex',
    description: 'Achieve sub-150ms reaction speed (Top 0.1%).',
    icon: '👑'
  },
  {
    id: 'flawless_series',
    title: 'Flawless Mind',
    description: 'Complete a 5-round challenge with zero false starts.',
    icon: '🎯'
  },
  {
    id: 'endurance_iron',
    title: 'Endurance Titan',
    description: 'Finish a 10-round endurance test with an average under 240ms.',
    icon: '🛡️'
  },
  {
    id: 'streak_3',
    title: 'Daily Warrior',
    description: 'Complete the daily challenge 3 days in a row.',
    icon: '📅'
  }
];

export function getTodayDateString(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function getDailyTarget(): { targetMs: number; description: string } {
  // Deterministic daily target based on date
  const today = getTodayDateString();
  let hash = 0;
  for (let i = 0; i < today.length; i++) {
    hash = (hash << 5) - hash + today.charCodeAt(i);
    hash |= 0;
  }
  const targets = [
    { targetMs: 235, description: "Hit under 235ms to clear today's reflex trial!" },
    { targetMs: 220, description: "Hit under 220ms to claim today's gold streak!" },
    { targetMs: 210, description: "Speed focus! Sub-210ms challenge for today." },
    { targetMs: 200, description: "Elite test! Crack the 200ms boundary today." },
    { targetMs: 225, description: "Sharpen reflexes! Sub-225ms daily objective." },
  ];
  const idx = Math.abs(hash) % targets.length;
  return targets[idx];
}

const DEFAULT_STATS: UserStats = {
  nickname: 'ReflexPilot',
  classicBest: null,
  fiveRoundsBestAvg: null,
  enduranceBestAvg: null,
  dailyStreak: 0,
  lastDailyDate: null,
  dailyCompletedToday: false,
  totalGamesPlayed: 0,
  totalFalseStarts: 0,
  unlockedAchievements: [],
  history: [],
  soundEnabled: true,
  hapticsEnabled: true,
};

export function loadUserStats(): UserStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATS;
    const parsed = JSON.parse(raw);
    const today = getTodayDateString();
    parsed.dailyCompletedToday = parsed.lastDailyDate === today;
    return { ...DEFAULT_STATS, ...parsed };
  } catch {
    return DEFAULT_STATS;
  }
}

export function saveUserStats(stats: UserStats): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch {
    // localStorage full or disabled
  }
}

export function getSavedNickname(): string {
  try {
    return localStorage.getItem(NICKNAME_KEY) || 'ReflexPilot';
  } catch {
    return 'ReflexPilot';
  }
}

export function setSavedNickname(name: string): void {
  try {
    localStorage.setItem(NICKNAME_KEY, name);
  } catch {
    // safe fallback
  }
}

export function saveGameResult(
  mode: GameMode,
  attempts: number[],
  falseStarts: number,
  rating: string,
  ratingColor: string
): { result: GameResult; isNewBest: boolean; newlyUnlockedAchievements: string[] } {
  const stats = loadUserStats();
  const validAttempts = attempts.filter((t) => t > 0);
  const averageMs = validAttempts.length > 0
    ? Math.round(validAttempts.reduce((a, b) => a + b, 0) / validAttempts.length)
    : 0;
  const fastestMs = validAttempts.length > 0 ? Math.min(...validAttempts) : 0;
  const slowestMs = validAttempts.length > 0 ? Math.max(...validAttempts) : 0;

  let isNewBest = false;
  if (mode === 'classic') {
    if (stats.classicBest === null || fastestMs < stats.classicBest) {
      stats.classicBest = fastestMs;
      isNewBest = true;
    }
  } else if (mode === 'five_rounds') {
    if (stats.fiveRoundsBestAvg === null || averageMs < stats.fiveRoundsBestAvg) {
      stats.fiveRoundsBestAvg = averageMs;
      isNewBest = true;
    }
  } else if (mode === 'endurance') {
    if (stats.enduranceBestAvg === null || averageMs < stats.enduranceBestAvg) {
      stats.enduranceBestAvg = averageMs;
      isNewBest = true;
    }
  } else if (mode === 'daily') {
    const today = getTodayDateString();
    const dailyGoal = getDailyTarget();
    if (fastestMs <= dailyGoal.targetMs && stats.lastDailyDate !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
      
      if (stats.lastDailyDate === yesterdayStr) {
        stats.dailyStreak += 1;
      } else {
        stats.dailyStreak = 1;
      }
      stats.lastDailyDate = today;
      stats.dailyCompletedToday = true;
    }
  }

  const result: GameResult = {
    id: 'res_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    mode,
    timestamp: Date.now(),
    attempts: validAttempts,
    averageMs,
    fastestMs,
    slowestMs,
    falseStarts,
    rating,
    ratingColor,
    isNewPersonalBest: isNewBest,
  };

  stats.history.unshift(result);
  if (stats.history.length > 40) {
    stats.history = stats.history.slice(0, 40);
  }

  stats.totalGamesPlayed += 1;
  stats.totalFalseStarts += falseStarts;

  // Check achievements
  const newlyUnlockedAchievements: string[] = [];
  const unlock = (id: string) => {
    if (!stats.unlockedAchievements.includes(id)) {
      stats.unlockedAchievements.push(id);
      newlyUnlockedAchievements.push(id);
    }
  };

  unlock('first_blood');
  if (fastestMs > 0 && fastestMs < 250) unlock('sub_250');
  if (fastestMs > 0 && fastestMs < 200) unlock('sub_200');
  if (fastestMs > 0 && fastestMs < 150) unlock('incredible_reflex');
  if (mode === 'five_rounds' && falseStarts === 0) unlock('flawless_series');
  if (mode === 'endurance' && averageMs > 0 && averageMs < 240) unlock('endurance_iron');
  if (stats.dailyStreak >= 3) unlock('streak_3');

  saveUserStats(stats);
  return { result, isNewBest, newlyUnlockedAchievements };
}

// Global leaderboard benchmarks + user rank
export function getLeaderboardEntries(mode: GameMode, userBest: number | null, userName: string): LeaderboardEntry[] {
  const baseEntries: Record<GameMode, Omit<LeaderboardEntry, 'rank' | 'isUser'>[]> = {
    classic: [
      { id: 'lb_1', name: 'Max Verstappen', timeMs: 148, mode: 'classic', tag: 'F1 Driver', date: 'Season 2026' },
      { id: 'lb_2', name: 's1mple (Oleksandr)', timeMs: 154, mode: 'classic', tag: 'CS2 Major MVP', date: '2026-10-18' },
      { id: 'lb_3', name: 'Usain Bolt', timeMs: 165, mode: 'classic', tag: 'Olympic Gold', date: 'Verified' },
      { id: 'lb_4', name: 'Faker (Sang-hyeok)', timeMs: 172, mode: 'classic', tag: 'LoL Legend', date: '2026-10-24' },
      { id: 'lb_5', name: 'Vortex_Reflex', timeMs: 179, mode: 'classic', tag: 'ReactionX Pro', date: 'Yesterday' },
      { id: 'lb_6', name: 'Tenz (Tyson Ngo)', timeMs: 185, mode: 'classic', tag: 'Valorant Pro', date: '2026-10-29' },
      { id: 'lb_7', name: 'CyberStriker', timeMs: 194, mode: 'classic', tag: 'Human Reflex Lab', date: '2 days ago' },
      { id: 'lb_8', name: 'NeonPulse99', timeMs: 204, mode: 'classic', tag: 'Community Tier 1', date: 'Today' },
      { id: 'lb_9', name: 'ApexPhantom', timeMs: 218, mode: 'classic', tag: 'Verified Human', date: 'Today' },
      { id: 'lb_10', name: 'ShadowPilot', timeMs: 231, mode: 'classic', tag: 'Fast Reflex', date: '3 days ago' },
    ],
    five_rounds: [
      { id: 'lb_5r_1', name: 'Max Verstappen', timeMs: 152, mode: 'five_rounds', tag: 'F1 Driver', date: 'Season 2026' },
      { id: 'lb_5r_2', name: 's1mple (Oleksandr)', timeMs: 159, mode: 'five_rounds', tag: 'CS2 Major MVP', date: '2026-10-18' },
      { id: 'lb_5r_3', name: 'Tenz (Tyson Ngo)', timeMs: 188, mode: 'five_rounds', tag: 'Valorant Pro', date: '2026-10-29' },
      { id: 'lb_5r_4', name: 'Vortex_Reflex', timeMs: 191, mode: 'five_rounds', tag: 'Consistency King', date: 'Yesterday' },
      { id: 'lb_5r_5', name: 'Faker (Sang-hyeok)', timeMs: 195, mode: 'five_rounds', tag: 'LoL Legend', date: '2026-10-24' },
      { id: 'lb_5r_6', name: 'ChronoZero', timeMs: 208, mode: 'five_rounds', tag: '5-Round Master', date: 'Today' },
      { id: 'lb_5r_7', name: 'AeroSync', timeMs: 221, mode: 'five_rounds', tag: 'Sharp Focus', date: '2 days ago' },
      { id: 'lb_5r_8', name: 'HyperMind', timeMs: 234, mode: 'five_rounds', tag: 'Community Tier 1', date: 'Today' },
    ],
    endurance: [
      { id: 'lb_end_1', name: 'Max Verstappen', timeMs: 155, mode: 'endurance', tag: 'F1 10-Lap Focus', date: 'Season 2026' },
      { id: 'lb_end_2', name: 's1mple (Oleksandr)', timeMs: 164, mode: 'endurance', tag: 'CS2 Marathon', date: '2026-10-18' },
      { id: 'lb_end_3', name: 'Vortex_Reflex', timeMs: 197, mode: 'endurance', tag: 'Endurance Pro', date: 'Yesterday' },
      { id: 'lb_end_4', name: 'TitanGamer', timeMs: 212, mode: 'endurance', tag: 'Precision 10/10', date: 'Today' },
      { id: 'lb_end_5', name: 'LaserSight', timeMs: 228, mode: 'endurance', tag: 'Zero Fade', date: '3 days ago' },
      { id: 'lb_end_6', name: 'Kinetics_X', timeMs: 242, mode: 'endurance', tag: 'Solid Rhythm', date: 'Today' },
    ],
    daily: [
      { id: 'lb_d_1', name: 's1mple (Oleksandr)', timeMs: 156, mode: 'daily', tag: 'Daily Gold', date: 'Today' },
      { id: 'lb_d_2', name: 'Tenz (Tyson Ngo)', timeMs: 181, mode: 'daily', tag: 'Streak 14', date: 'Today' },
      { id: 'lb_d_3', name: 'Vortex_Reflex', timeMs: 189, mode: 'daily', tag: 'Streak 31', date: 'Today' },
      { id: 'lb_d_4', name: 'NeonPulse99', timeMs: 202, mode: 'daily', tag: 'Streak 9', date: 'Today' },
      { id: 'lb_d_5', name: 'ApexPhantom', timeMs: 215, mode: 'daily', tag: 'Streak 5', date: 'Today' },
    ]
  };

  const list = [...baseEntries[mode]];

  if (userBest !== null && userBest > 0) {
    list.push({
      id: 'user_entry',
      name: userName || 'You',
      timeMs: userBest,
      mode,
      tag: 'YOUR PERSONAL BEST',
      date: 'Personal Best',
    });
  }

  // Sort lowest ms first
  list.sort((a, b) => a.timeMs - b.timeMs);

  return list.map((item, index) => ({
    ...item,
    rank: index + 1,
    isUser: item.id === 'user_entry'
  }));
}
