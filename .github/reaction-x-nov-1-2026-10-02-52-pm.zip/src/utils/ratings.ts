import { PerformanceRating } from '../types/game';

export function getPerformanceRating(timeMs: number): PerformanceRating {
  if (timeMs < 150) {
    return {
      tier: 'GODLIKE',
      label: 'Incredible',
      color: '#00f0ff',
      bgColor: 'bg-cyan-500/15',
      borderColor: 'border-cyan-400',
      description: 'Superhuman neural latency. Faster than 99.9% of the global population.',
      percentile: 'Top 0.1%'
    };
  }
  if (timeMs <= 200) {
    return {
      tier: 'ELITE',
      label: 'Lightning Fast',
      color: '#00ff66',
      bgColor: 'bg-emerald-500/15',
      borderColor: 'border-emerald-400',
      description: 'Formula 1 & Pro Esports reflex level. World-class visual-motor response.',
      percentile: 'Top 2%'
    };
  }
  if (timeMs <= 250) {
    return {
      tier: 'PRO',
      label: 'Excellent',
      color: '#a855f7',
      bgColor: 'bg-purple-500/15',
      borderColor: 'border-purple-400',
      description: 'Well above average. Extremely sharp cognitive anticipation and motor speed.',
      percentile: 'Top 15%'
    };
  }
  if (timeMs <= 300) {
    return {
      tier: 'SHARP',
      label: 'Good',
      color: '#38bdf8',
      bgColor: 'bg-sky-500/15',
      borderColor: 'border-sky-400',
      description: 'Solid reaction speed. Healthy benchmark for focused adults.',
      percentile: 'Top 40%'
    };
  }
  if (timeMs <= 400) {
    return {
      tier: 'CASUAL',
      label: 'Average',
      color: '#fbbf24',
      bgColor: 'bg-amber-500/15',
      borderColor: 'border-amber-400',
      description: 'Standard casual reaction speed. You can get significantly faster with practice.',
      percentile: 'Top 65%'
    };
  }
  return {
    tier: 'ROOKIE',
    label: 'Keep Practicing',
    color: '#ff2a55',
    bgColor: 'bg-rose-500/15',
    borderColor: 'border-rose-400',
    description: 'A bit sluggish or distracted. Take a deep breath, focus your eyes, and try again!',
    percentile: 'Bottom 35%'
  };
}

export function formatMs(timeMs: number | null | undefined): string {
  if (timeMs == null || isNaN(timeMs)) return '---';
  return Math.round(timeMs).toString();
}
