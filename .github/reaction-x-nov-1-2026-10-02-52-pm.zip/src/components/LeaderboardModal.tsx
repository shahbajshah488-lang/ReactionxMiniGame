import React, { useState } from 'react';
import { X, Trophy, Award, Edit2, Check, Zap, Download } from 'lucide-react';
import { GameMode, UserStats } from '../types/game';
import { getLeaderboardEntries, ALL_ACHIEVEMENTS } from '../utils/storage';
import { getPerformanceRating } from '../utils/ratings';
import { downloadHistoryCSV } from '../utils/shareCard';

interface LeaderboardModalProps {
  stats: UserStats;
  isOpen: boolean;
  onClose: () => void;
  onUpdateNickname: (newNick: string) => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  stats,
  isOpen,
  onClose,
  onUpdateNickname,
}) => {
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'achievements'>('leaderboard');
  const [selectedMode, setSelectedMode] = useState<GameMode>('classic');
  const [isEditingNick, setIsEditingNick] = useState(false);
  const [nickInput, setNickInput] = useState(stats.nickname);

  if (!isOpen) return null;

  const userBestForMode = selectedMode === 'classic' 
    ? stats.classicBest 
    : selectedMode === 'five_rounds' 
    ? stats.fiveRoundsBestAvg 
    : selectedMode === 'endurance' 
    ? stats.enduranceBestAvg 
    : stats.classicBest;

  const entries = getLeaderboardEntries(selectedMode, userBestForMode, stats.nickname);

  const handleSaveNick = () => {
    if (nickInput.trim()) {
      onUpdateNickname(nickInput.trim());
      setIsEditingNick(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-2xl max-h-[90vh] bg-neutral-950 border border-neutral-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-white">Global Leaderboard & Records</h2>
              <p className="text-xs text-neutral-400">Global benchmarks vs your verified reflex trials</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch & Pilot Nickname bar */}
        <div className="px-4 sm:px-6 pt-4 pb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-900">
          {/* Main Tabs */}
          <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'leaderboard'
                  ? 'bg-neutral-800 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Leaderboards
            </button>
            <button
              onClick={() => setActiveTab('achievements')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'achievements'
                  ? 'bg-neutral-800 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-purple-400" />
              <span>Achievements ({stats.unlockedAchievements.length}/{ALL_ACHIEVEMENTS.length})</span>
            </button>
          </div>

          {/* Nickname Editor */}
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-neutral-500">PILOT:</span>
            {isEditingNick ? (
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  maxLength={16}
                  value={nickInput}
                  onChange={(e) => setNickInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSaveNick()}
                  className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-700 text-white font-mono text-xs w-28 focus:outline-none focus:border-emerald-400"
                  autoFocus
                />
                <button
                  onClick={handleSaveNick}
                  className="p-1 rounded bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                >
                  <Check className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setNickInput(stats.nickname);
                  setIsEditingNick(true);
                }}
                className="flex items-center gap-1.5 text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 px-2 py-1 rounded border border-neutral-800 transition-colors"
              >
                <span className="font-bold">{stats.nickname}</span>
                <Edit2 className="w-3 h-3 text-neutral-400" />
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        {activeTab === 'leaderboard' ? (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1">
            {/* Mode Filter Pills */}
            <div className="flex items-center gap-1.5 mb-4 overflow-x-auto pb-1 text-xs font-mono">
              <button
                onClick={() => setSelectedMode('classic')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer shrink-0 ${
                  selectedMode === 'classic'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Classic (1 Round)
              </button>
              <button
                onClick={() => setSelectedMode('five_rounds')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer shrink-0 ${
                  selectedMode === 'five_rounds'
                    ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                5-Round Avg
              </button>
              <button
                onClick={() => setSelectedMode('endurance')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer shrink-0 ${
                  selectedMode === 'endurance'
                    ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Endurance (10 Rounds)
              </button>
              <button
                onClick={() => setSelectedMode('daily')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer shrink-0 ${
                  selectedMode === 'daily'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Daily Streak
              </button>
            </div>

            {/* Entries List */}
            <div className="space-y-2">
              {entries.map((entry) => {
                const rating = getPerformanceRating(entry.timeMs);
                return (
                  <div
                    key={entry.id}
                    className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                      entry.isUser
                        ? 'bg-emerald-950/40 border-emerald-500/60 glow-green'
                        : 'bg-neutral-900/50 border-neutral-800/80 hover:bg-neutral-900'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* Rank badge */}
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                          entry.rank === 1
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                            : entry.rank === 2
                            ? 'bg-slate-300/20 text-slate-200 border border-slate-300/50'
                            : entry.rank === 3
                            ? 'bg-amber-700/20 text-amber-500 border border-amber-700/50'
                            : 'text-neutral-500'
                        }`}
                      >
                        #{entry.rank}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-bold ${entry.isUser ? 'text-emerald-300' : 'text-white'}`}>
                            {entry.name}
                          </span>
                          {entry.isUser && (
                            <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-500 text-black">
                              YOU
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono flex items-center gap-2">
                          <span>{entry.tag}</span>
                          <span>·</span>
                          <span className="text-neutral-400">{entry.date}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="flex items-baseline justify-end gap-1 font-mono font-bold">
                        <span className="text-lg text-white">{entry.timeMs}</span>
                        <span className="text-xs text-emerald-400">ms</span>
                      </div>
                      <span
                        className="text-[10px] font-mono font-semibold"
                        style={{ color: rating.color }}
                      >
                        {rating.label}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Achievements Tab */
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-3">
            {ALL_ACHIEVEMENTS.map((ach) => {
              const isUnlocked = stats.unlockedAchievements.includes(ach.id);
              return (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-xl border flex items-center gap-3.5 ${
                    isUnlocked
                      ? 'bg-purple-950/20 border-purple-500/40'
                      : 'bg-neutral-900/30 border-neutral-900 opacity-50'
                  }`}
                >
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 ${
                    isUnlocked ? 'bg-purple-500/20 border border-purple-500/40' : 'bg-neutral-900 border border-neutral-800'
                  }`}>
                    {ach.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-0.5">
                      <h4 className={`text-sm font-bold ${isUnlocked ? 'text-white' : 'text-neutral-400'}`}>
                        {ach.title}
                      </h4>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        isUnlocked ? 'bg-purple-500/20 text-purple-300' : 'bg-neutral-800 text-neutral-400'
                      }`}>
                        {isUnlocked ? 'UNLOCKED ✓' : 'LOCKED'}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400">
                      {ach.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400 font-mono">
          <div className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>Scores stored locally & verified</span>
          </div>
          <div className="flex items-center gap-2">
            {stats.history.length > 0 && (
              <button
                onClick={() => downloadHistoryCSV(stats.history, stats.nickname)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/60 text-neutral-200 hover:text-white font-semibold transition-colors cursor-pointer"
                title="Download all reaction test telemetry as CSV"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Download CSV</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white font-semibold cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
