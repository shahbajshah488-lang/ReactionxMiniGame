import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameMode, GamePhase } from '../types/game';
import { soundManager } from '../utils/sound';
import { getPerformanceRating } from '../utils/ratings';
import { Zap, AlertTriangle, ArrowRight, RotateCcw } from 'lucide-react';

interface GameArenaProps {
  mode: GameMode;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onGameComplete: (attempts: number[], falseStarts: number) => void;
  onExitGame: () => void;
}

export const GameArena: React.FC<GameArenaProps> = ({
  mode,
  soundEnabled,
  hapticsEnabled,
  onGameComplete,
  onExitGame,
}) => {
  const totalRounds = mode === 'classic' ? 1 : mode === 'five_rounds' ? 5 : mode === 'endurance' ? 10 : 3;

  const [currentRound, setCurrentRound] = useState(1);
  const [phase, setPhase] = useState<GamePhase>('COUNTDOWN');
  const [countdownNum, setCountdownNum] = useState(3);
  const [roundTimeMs, setRoundTimeMs] = useState<number | null>(null);
  const [attempts, setAttempts] = useState<number[]>([]);
  const [falseStartsCount, setFalseStartsCount] = useState(0);

  // References to keep strict timing and avoid closure staleness
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const greenStartTimeRef = useRef<number>(0);
  const clickHandledRef = useRef<boolean>(false);
  const phaseRef = useRef<GamePhase>('COUNTDOWN');
  phaseRef.current = phase;

  // Clear any pending timers
  const clearCurrentTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  // 1. Start Countdown (3, 2, 1)
  const startCountdown = useCallback(() => {
    clearCurrentTimer();
    clickHandledRef.current = false;
    setPhase('COUNTDOWN');
    setCountdownNum(3);
    soundManager.playCountdown(3, soundEnabled);
    soundManager.triggerHaptic('light', hapticsEnabled);

    let count = 3;
    const interval = setInterval(() => {
      count -= 1;
      if (count > 0) {
        setCountdownNum(count);
        soundManager.playCountdown(count, soundEnabled);
        soundManager.triggerHaptic('light', hapticsEnabled);
      } else {
        clearInterval(interval);
        // Transition to WAITING (Red screen)
        startWaiting();
      }
    }, 800);

    timerRef.current = interval as unknown as NodeJS.Timeout;
  }, [clearCurrentTimer, soundEnabled, hapticsEnabled]);

  // 2. Start Waiting (Red screen)
  const startWaiting = useCallback(() => {
    clearCurrentTimer();
    clickHandledRef.current = false;
    setPhase('WAITING');
    setRoundTimeMs(null);

    // Random wait between 2000ms and 5000ms
    const randomDelay = Math.floor(Math.random() * 3000) + 2000;

    timerRef.current = setTimeout(() => {
      // Trigger Green Signal!
      setPhase('READY');
      greenStartTimeRef.current = performance.now();
      clickHandledRef.current = false;
      soundManager.playGreenSignal(soundEnabled);
      soundManager.triggerHaptic('light', hapticsEnabled);
    }, randomDelay);
  }, [clearCurrentTimer, soundEnabled, hapticsEnabled]);

  // Handle Initial Mount
  useEffect(() => {
    startCountdown();
    return () => {
      clearCurrentTimer();
    };
  }, []);

  // User input / pointer event handler
  const handleInteraction = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (clickHandledRef.current) return;

    if (phase === 'COUNTDOWN') {
      // Ignore click during initial 3-2-1 countdown
      return;
    }

    if (phase === 'WAITING') {
      // Clicked while screen is RED -> TOO EARLY! False start!
      clickHandledRef.current = true;
      clearCurrentTimer();
      setPhase('FALSE_START');
      setFalseStartsCount((prev) => prev + 1);
      soundManager.playError(soundEnabled);
      soundManager.triggerHaptic('error', hapticsEnabled);
      return;
    }

    if (phase === 'READY') {
      // Valid reaction click!
      clickHandledRef.current = true;
      const endTime = performance.now();
      const reaction = Math.round(endTime - greenStartTimeRef.current);
      setRoundTimeMs(reaction);
      
      const newAttempts = [...attempts, reaction];
      setAttempts(newAttempts);

      soundManager.playSuccess(soundEnabled);
      soundManager.triggerHaptic('success', hapticsEnabled);

      if (currentRound >= totalRounds) {
        // Last round reached!
        setPhase('ROUND_RESULT');
        // Briefly display final round result then transition to game over
        setTimeout(() => {
          onGameComplete(newAttempts, falseStartsCount);
        }, 1200);
      } else {
        // Multi-round progression
        setPhase('ROUND_RESULT');
      }
      return;
    }

    if (phase === 'FALSE_START') {
      // Tap to retry this round
      startWaiting();
      return;
    }

    if (phase === 'ROUND_RESULT') {
      if (currentRound < totalRounds) {
        advanceToNextRound();
      }
    }
  };

  const advanceToNextRound = () => {
    setCurrentRound((prev) => prev + 1);
    startWaiting();
  };

  const currentRating = roundTimeMs ? getPerformanceRating(roundTimeMs) : null;

  return (
    <div
      onPointerDown={handleInteraction}
      className={`relative w-full h-[calc(100vh-65px)] max-h-[850px] min-h-[500px] flex flex-col justify-between items-center select-none overflow-hidden rounded-2xl transition-colors duration-150 cursor-pointer touch-none ${
        phase === 'COUNTDOWN'
          ? 'bg-neutral-950 border border-neutral-800'
          : phase === 'WAITING'
          ? 'bg-gradient-to-b from-rose-950 via-rose-900 to-black border-2 border-rose-600 glow-red'
          : phase === 'READY'
          ? 'bg-emerald-500 border-4 border-emerald-300 glow-green-lg'
          : phase === 'FALSE_START'
          ? 'bg-rose-950 border-2 border-rose-500'
          : 'bg-neutral-900 border border-neutral-800'
      }`}
    >
      {/* HUD Top Bar */}
      <div className="w-full px-4 sm:px-6 py-4 flex items-center justify-between z-10 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-md bg-black/50 border border-white/10 text-white font-semibold">
            ROUND {currentRound} / {totalRounds}
          </span>
          {falseStartsCount > 0 && (
            <span className="px-2 py-1 rounded-md bg-rose-900/60 border border-rose-500/40 text-rose-300 flex items-center gap-1 font-semibold">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{falseStartsCount} False {falseStartsCount === 1 ? 'Start' : 'Starts'}</span>
            </span>
          )}
        </div>

        {/* Progress Dots */}
        <div className="flex items-center gap-1.5">
          {Array.from({ length: totalRounds }).map((_, idx) => {
            const isCompleted = idx < attempts.length;
            const isCurrent = idx === currentRound - 1;
            return (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all duration-200 ${
                  isCurrent
                    ? 'w-6 bg-white shadow-sm'
                    : isCompleted
                    ? 'w-2 bg-emerald-400'
                    : 'w-2 bg-white/20'
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* Center Interactive Zone */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-4 z-10 pointer-events-none">
        {/* Phase 1: COUNTDOWN */}
        {phase === 'COUNTDOWN' && (
          <div className="flex flex-col items-center animate-pulse-fast">
            <span className="text-xs uppercase tracking-widest text-neutral-400 font-mono mb-2">
              GET READY · ROUND {currentRound}
            </span>
            <div className="text-8xl sm:text-9xl font-extrabold font-display text-white">
              {countdownNum}
            </div>
            <p className="text-xs text-neutral-400 mt-4 max-w-xs">
              Prepare your finger. Do NOT click until the screen turns bright green.
            </p>
          </div>
        )}

        {/* Phase 2: WAITING (Red screen) */}
        {phase === 'WAITING' && (
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-rose-500/20 border-2 border-rose-400 flex items-center justify-center mb-6 animate-pulse">
              <div className="w-8 h-8 rounded-full bg-rose-500" />
            </div>
            <h2 className="text-4xl sm:text-6xl font-extrabold font-display tracking-tight text-white mb-3 text-glow-red">
              WAIT FOR GREEN
            </h2>
            <p className="text-sm sm:text-base text-rose-200/80 font-medium">
              Keep your finger steady. Clicking early counts as a false start.
            </p>
          </div>
        )}

        {/* Phase 3: READY (Green screen) */}
        {phase === 'READY' && (
          <div className="flex flex-col items-center scale-110 transition-transform">
            <div className="w-24 h-24 rounded-full bg-black/20 flex items-center justify-center mb-4 text-black">
              <Zap className="w-12 h-12 fill-black stroke-black" />
            </div>
            <h2 className="text-5xl sm:text-7xl font-black font-display tracking-tight text-black mb-1 drop-shadow-md">
              CLICK NOW!
            </h2>
            <p className="text-base sm:text-lg text-black/80 font-bold tracking-wide uppercase font-mono">
              STRIKE INSTANTLY!
            </p>
          </div>
        )}

        {/* Phase 4: FALSE START */}
        {phase === 'FALSE_START' && (
          <div className="flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-rose-600/30 border-2 border-rose-400 flex items-center justify-center mb-4 text-rose-300">
              <AlertTriangle className="w-10 h-10 text-rose-400" />
            </div>
            <h2 className="text-4xl sm:text-6xl font-extrabold font-display text-rose-400 mb-2 text-glow-red">
              TOO EARLY!
            </h2>
            <p className="text-sm text-neutral-300 mb-6">
              You clicked before the green signal appeared. False start recorded.
            </p>
            <div className="px-5 py-2.5 rounded-xl bg-white text-black font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 pointer-events-auto">
              <RotateCcw className="w-4 h-4" />
              <span>Tap to Try Again</span>
            </div>
          </div>
        )}

        {/* Phase 5: ROUND RESULT */}
        {phase === 'ROUND_RESULT' && roundTimeMs !== null && currentRating && (
          <div className="flex flex-col items-center">
            <span className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2">
              ROUND {currentRound} REACTION SPEED
            </span>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-6xl sm:text-8xl font-black font-mono text-white tracking-tight">
                {roundTimeMs}
              </span>
              <span className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400">
                ms
              </span>
            </div>
            <div
              className="text-xs px-3 py-1 rounded-md font-bold font-mono uppercase tracking-wider mb-6 border"
              style={{
                color: currentRating.color,
                borderColor: `${currentRating.color}40`,
                backgroundColor: `${currentRating.color}15`,
              }}
            >
              {currentRating.label} · {currentRating.percentile}
            </div>

            {currentRound < totalRounds ? (
              <div className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-black font-extrabold text-xs uppercase tracking-wider pointer-events-auto">
                <span>Continue to Round {currentRound + 1}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            ) : (
              <p className="text-xs font-mono text-neutral-400 animate-pulse">
                Calculating final reflex evaluation...
              </p>
            )}
          </div>
        )}
      </div>

      {/* Footer Instructions / Controls */}
      <div className="w-full px-6 py-4 flex items-center justify-between z-10 text-xs text-neutral-400">
        <span className="font-mono text-[11px] opacity-70">
          {phase === 'READY'
            ? '⚡ INSTANT MOTOR RESPONSE'
            : phase === 'WAITING'
            ? 'HOLD STILL'
            : phase === 'FALSE_START'
            ? 'TAP SCREEN TO RESTART ROUND'
            : 'ANY CLICK REGISTERS REACTION'}
        </span>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onExitGame();
          }}
          className="text-neutral-400 hover:text-white underline text-xs pointer-events-auto cursor-pointer"
        >
          Exit Game
        </button>
      </div>
    </div>
  );
};
