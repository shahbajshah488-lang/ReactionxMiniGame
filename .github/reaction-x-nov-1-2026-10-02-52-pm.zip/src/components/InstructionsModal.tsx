import React from 'react';
import { X, HelpCircle, Zap, AlertTriangle, ShieldCheck, Cpu } from 'lucide-react';

interface InstructionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstructionsModal: React.FC<InstructionsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-2xl max-h-[90vh] bg-neutral-950 border border-neutral-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-display text-white">How to Play & Reflex Science</h2>
              <p className="text-xs text-neutral-400">Rules, human neurology, and pro reaction tips</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 text-sm text-neutral-300">
          {/* Rules Walkthrough */}
          <section>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              <span>Gameplay Rules</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-xs font-mono font-bold text-rose-400 block mb-1">01. WAIT FOR GREEN</span>
                <p className="text-xs text-neutral-400">
                  The screen turns red. A randomized delay between 2 and 5 seconds begins.
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-xs font-mono font-bold text-emerald-400 block mb-1">02. CLICK NOW!</span>
                <p className="text-xs text-neutral-400">
                  When the neon green signal flashes, tap or click anywhere as fast as you can.
                </p>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
                <span className="text-xs font-mono font-bold text-amber-400 block mb-1">03. AVOID FALSE STARTS</span>
                <p className="text-xs text-neutral-400">
                  Clicking too early triggers "TOO EARLY!" and penalizes your record.
                </p>
              </div>
            </div>
          </section>

          {/* Performance Tiers Matrix */}
          <section>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Official Performance Tiers</span>
            </h3>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-cyan-400">&lt; 150 ms</span>
                <span className="font-bold text-white">Incredible</span>
                <span className="text-neutral-400">Top 0.1% Superhuman Reflex</span>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-emerald-400">150–200 ms</span>
                <span className="font-bold text-white">Lightning Fast</span>
                <span className="text-neutral-400">Top 2% Esports & F1 Pro</span>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-purple-400">201–250 ms</span>
                <span className="font-bold text-white">Excellent</span>
                <span className="text-neutral-400">Top 15% Above Average</span>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-sky-400">251–300 ms</span>
                <span className="font-bold text-white">Good</span>
                <span className="text-neutral-400">Top 40% Standard Human</span>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-amber-400">301–400 ms</span>
                <span className="font-bold text-white">Average</span>
                <span className="text-neutral-400">Top 65% Casual Pace</span>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-900/50 border border-neutral-800 flex items-center justify-between">
                <span className="font-bold text-rose-400">&gt; 400 ms</span>
                <span className="font-bold text-white">Keep Practicing</span>
                <span className="text-neutral-400">Warm Up & Retest</span>
              </div>
            </div>
          </section>

          {/* The Science of Reflex */}
          <section className="p-4 rounded-2xl bg-neutral-900/40 border border-neutral-800">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-sky-400 mb-2 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" />
              <span>Neurological Reflex Latency Breakdown</span>
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed mb-3">
              When light hits your eyes, your nervous system must execute four discrete biological operations before your finger physically twitches:
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-mono">
              <div className="p-2 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-emerald-400 font-bold block">20-40 ms</span>
                <span className="text-[10px] text-neutral-400">Retinal Photoreceptors</span>
              </div>
              <div className="p-2 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-purple-400 font-bold block">60-80 ms</span>
                <span className="text-[10px] text-neutral-400">Visual Cortex Deciding</span>
              </div>
              <div className="p-2 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-sky-400 font-bold block">30-50 ms</span>
                <span className="text-[10px] text-neutral-400">Spinal Conduction</span>
              </div>
              <div className="p-2 rounded-lg bg-neutral-950 border border-neutral-800">
                <span className="text-amber-400 font-bold block">20-30 ms</span>
                <span className="text-[10px] text-neutral-400">Muscle Contraction</span>
              </div>
            </div>
          </section>

          {/* Pro Tips */}
          <section>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 mb-2">
              Pro Tips for Faster Milliseconds
            </h3>
            <ul className="text-xs text-neutral-400 space-y-1.5 list-disc pl-4">
              <li>Keep your finger resting mere millimeters above the mouse button or touch screen.</li>
              <li>Use soft focus on the center rather than tensing your eye muscles.</li>
              <li>Exhale gently during the countdown; tense holding slows nervous impulses.</li>
              <li>Higher display refresh rates (120Hz/144Hz) save up to 8ms of display latency.</li>
            </ul>
          </section>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Got It, Let's Play
          </button>
        </div>
      </div>
    </div>
  );
};
