import React from 'react';
import { Play, Flame, Gauge, Zap, Calendar, Target, Award, ShieldAlert, Download } from 'lucide-react';
import { GameMode, UserStats } from '../types/game';
import { getPerformanceRating } from '../utils/ratings';

interface StartScreenProps {
  stats: UserStats;
  dailyGoal: { targetMs: number; description: string };
  challengerData: { score: number; name: string; mode: GameMode } | null;
  onSelectMode: (mode: GameMode) => void;
  onClearChallenge: () => void;
  onOpenBestScoreCard?: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  stats,
  dailyGoal,
  challengerData,
  onSelectMode,
  onClearChallenge,
  onOpenBestScoreCard,
}) => {
  const overallBest = stats.classicBest;
  const rating = overallBest ? getPerformanceRating(overallBest) : null;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 flex flex-col items-center">
      {/* Challenger Alert Banner */}
      {challengerData && (
        <div className="w-full mb-6 p-4 rounded-xl bg-purple-950/40 border border-purple-500/40 glow-purple flex flex-col sm:flex-row items-center justify-between gap-3 animate-pulse-fast">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 border border-purple-400 flex items-center justify-center shrink-0 text-purple-300">
              <ShieldAlert className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-purple-300 font-mono font-semibold">Incoming Reflex Challenge</p>
              <p className="text-sm sm:text-base font-bold text-white">
                <span className="text-purple-400">{challengerData.name}</span> challenged you to beat{' '}
                <span className="text-emerald-400 font-mono text-lg">{challengerData.score} ms</span>!
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSelectMode(challengerData.mode)}
              className="px-4 py-2 bg-purple-500 hover:bg-purple-400 text-black font-extrabold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
            >
              Accept Challenge
            </button>
            <button
              onClick={onClearChallenge}
              className="px-2.5 py-2 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Hero Title Section */}
      <div className="text-center mb-8 sm:mb-10 max-w-xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-xs text-neutral-400 mb-3">
          <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
          <span>High-Precision Human Latency Benchmark</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold font-display tracking-tight text-white mb-2">
          REACTION <span className="text-emerald-400 text-glow-green">X</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-md mx-auto">
          Test your neural reflexes down to the exact millisecond. Wait for the signal and strike instantly.
        </p>
      </div>

      {/* Personal Best Stat Spotlight */}
      {overallBest && rating && (
        <div className="w-full max-w-lg mb-8 p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-neutral-800/80 text-amber-400 border border-neutral-700/60 shrink-0">
              <Award className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="text-xs text-neutral-400 font-mono">PERSONAL BEST</div>
              <div className="text-xl font-bold font-mono text-white flex items-baseline gap-1">
                <span>{overallBest}</span>
                <span className="text-xs text-emerald-400">ms</span>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between sm:justify-end gap-2.5 w-full sm:w-auto">
            <div className="text-left sm:text-right">
              <span
                className="text-xs px-2.5 py-1 rounded-md font-bold font-mono inline-block border"
                style={{
                  color: rating.color,
                  borderColor: `${rating.color}40`,
                  backgroundColor: `${rating.color}15`,
                }}
              >
                {rating.label.toUpperCase()}
              </span>
              <div className="text-[11px] text-neutral-400 mt-0.5">{rating.percentile}</div>
            </div>
            {onOpenBestScoreCard && (
              <button
                onClick={onOpenBestScoreCard}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold transition-colors cursor-pointer shadow-sm shrink-0"
                title="Download official score card PNG"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Card</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Mode Selection Grid */}
      <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {/* Mode 1: Classic */}
        <button
          onClick={() => onSelectMode('classic')}
          className="group relative p-5 rounded-2xl bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800 hover:border-emerald-500/50 transition-all duration-200 text-left flex flex-col justify-between cursor-pointer overflow-hidden hover:shadow-[0_0_30px_rgba(0,255,102,0.15)]"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <Zap className="w-6 h-6 fill-emerald-400/20" />
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-neutral-400 block">Personal Best</span>
              <span className="text-sm font-bold text-emerald-400">
                {stats.classicBest ? `${stats.classicBest} ms` : 'Not Set'}
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors">
                Classic Mode
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                1 Round
              </span>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              Single-burst pure reaction test. Fastest way to gauge your baseline reflex right now.
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs font-semibold text-emerald-400">
            <span>Play Classic</span>
            <Play className="w-4 h-4 group-hover:translate-x-1 transition-transform fill-current" />
          </div>
        </button>

        {/* Mode 2: 5-Round Challenge */}
        <button
          onClick={() => onSelectMode('five_rounds')}
          className="group relative p-5 rounded-2xl bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800 hover:border-purple-500/50 transition-all duration-200 text-left flex flex-col justify-between cursor-pointer overflow-hidden hover:shadow-[0_0_30px_rgba(168,85,247,0.15)]"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
              <Target className="w-6 h-6" />
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-neutral-400 block">Best Average</span>
              <span className="text-sm font-bold text-purple-400">
                {stats.fiveRoundsBestAvg ? `${stats.fiveRoundsBestAvg} ms` : 'Not Set'}
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-purple-400 transition-colors">
                5-Round Challenge
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                5 Rounds
              </span>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              Esports competition standard. Computes your average, fastest round, and slowest outlier.
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs font-semibold text-purple-400">
            <span>Start 5 Rounds</span>
            <Play className="w-4 h-4 group-hover:translate-x-1 transition-transform fill-current" />
          </div>
        </button>

        {/* Mode 3: Endurance Mode */}
        <button
          onClick={() => onSelectMode('endurance')}
          className="group relative p-5 rounded-2xl bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800 hover:border-sky-500/50 transition-all duration-200 text-left flex flex-col justify-between cursor-pointer overflow-hidden hover:shadow-[0_0_30px_rgba(56,189,248,0.15)]"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 group-hover:scale-110 transition-transform">
              <Gauge className="w-6 h-6" />
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-neutral-400 block">Best Average</span>
              <span className="text-sm font-bold text-sky-400">
                {stats.enduranceBestAvg ? `${stats.enduranceBestAvg} ms` : 'Not Set'}
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-sky-400 transition-colors">
                Endurance Mode
              </h3>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                10 Rounds
              </span>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              Ultimate mental focus trial. 10 rapid rounds to measure neural fatigue and consistency.
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs font-semibold text-sky-400">
            <span>Enter Endurance</span>
            <Play className="w-4 h-4 group-hover:translate-x-1 transition-transform fill-current" />
          </div>
        </button>

        {/* Mode 4: Daily Challenge */}
        <button
          onClick={() => onSelectMode('daily')}
          className="group relative p-5 rounded-2xl bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 transition-all duration-200 text-left flex flex-col justify-between cursor-pointer overflow-hidden hover:shadow-[0_0_30px_rgba(251,191,36,0.15)]"
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
              <Calendar className="w-6 h-6" />
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-neutral-400 block">Daily Streak</span>
              <span className="text-sm font-bold text-amber-400 flex items-center justify-end gap-1">
                <Flame className="w-3.5 h-3.5 fill-amber-400" />
                <span>{stats.dailyStreak} {stats.dailyStreak === 1 ? 'Day' : 'Days'}</span>
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                Daily Challenge
              </h3>
              <span className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                stats.dailyCompletedToday ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-amber-950 text-amber-300 border border-amber-800/60'
              }`}>
                {stats.dailyCompletedToday ? 'Done Today ✓' : 'Daily Goal'}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mb-4">
              {dailyGoal.description}
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs font-semibold text-amber-400">
            <span>{stats.dailyCompletedToday ? 'Play Again Today' : 'Claim Daily Gold'}</span>
            <Play className="w-4 h-4 group-hover:translate-x-1 transition-transform fill-current" />
          </div>
        </button>
      </div>

      {/* Human Benchmarks Footer Bar */}
      <div className="w-full max-w-3xl py-3 px-4 rounded-xl bg-neutral-950/80 border border-neutral-800/80 flex flex-wrap items-center justify-around gap-4 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>F1 / Esports: <strong className="text-neutral-200 font-mono">&lt; 180 ms</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>Above Average: <strong className="text-neutral-200 font-mono">180–230 ms</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-400" />
          <span>Average Human: <strong className="text-neutral-200 font-mono">250–270 ms</strong></span>
        </div>
      </div>
    </div>
  );
};
