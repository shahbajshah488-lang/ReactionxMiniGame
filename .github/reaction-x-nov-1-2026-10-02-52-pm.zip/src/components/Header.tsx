import React from 'react';
import { Volume2, VolumeX, Smartphone, Trophy, HelpCircle, ArrowLeft, Zap } from 'lucide-react';
import { GamePhase } from '../types/game';

interface HeaderProps {
  currentPhase: GamePhase;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onOpenLeaderboard: () => void;
  onOpenInstructions: () => void;
  onGoHome: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPhase,
  soundEnabled,
  hapticsEnabled,
  onToggleSound,
  onToggleHaptics,
  onOpenLeaderboard,
  onOpenInstructions,
  onGoHome,
}) => {
  const isInGame = currentPhase !== 'IDLE';

  return (
    <header className="w-full max-w-5xl mx-auto px-4 py-3 flex items-center justify-between z-30 select-none">
      {/* Brand Zone */}
      <div className="flex items-center gap-3">
        {isInGame ? (
          <button
            onClick={onGoHome}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700/60 rounded-lg transition-colors cursor-pointer"
            aria-label="Back to main menu"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Menu</span>
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Zap className="w-4 h-4 fill-emerald-400" />
            </div>
            <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-white">
              REACTION <span className="text-emerald-400">X</span>
            </span>
          </div>
        )}
      </div>

      {/* Controls & Nav */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenLeaderboard}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700/60 rounded-lg transition-colors cursor-pointer"
          title="Global Leaderboard"
        >
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Leaderboard</span>
        </button>

        <button
          onClick={onOpenInstructions}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700/60 rounded-lg transition-colors cursor-pointer"
          title="Reflex Science & Guide"
        >
          <HelpCircle className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden sm:inline">Guide</span>
        </button>

        {/* Audio Toggle */}
        <button
          onClick={onToggleSound}
          className={`p-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
            soundEnabled
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-400'
          }`}
          title={soundEnabled ? 'Mute sound' : 'Enable sound'}
          aria-label={soundEnabled ? 'Mute sound' : 'Enable sound'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Haptics Toggle */}
        <button
          onClick={onToggleHaptics}
          className={`p-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
            hapticsEnabled
              ? 'bg-purple-500/10 border-purple-500/30 text-purple-400 hover:bg-purple-500/20'
              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-400'
          }`}
          title={hapticsEnabled ? 'Disable haptics' : 'Enable haptics'}
          aria-label={hapticsEnabled ? 'Disable haptics' : 'Enable haptics'}
        >
          <Smartphone className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
