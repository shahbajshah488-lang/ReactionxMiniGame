import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  RotateCcw, 
  Share2, 
  Trophy, 
  Award, 
  Zap, 
  ArrowUpRight, 
  ArrowDownRight, 
  Sparkles,
  Home,
  MessageCircle,
  Download
} from 'lucide-react';
import { GameResult, UserStats } from '../types/game';
import { getPerformanceRating } from '../utils/ratings';

interface ResultsDashboardProps {
  result: GameResult;
  stats: UserStats;
  isNewPersonalBest: boolean;
  newAchievements: string[];
  onPlayAgain: () => void;
  onGoHome: () => void;
  onOpenScoreCardModal: () => void;
  onShareWhatsApp: () => void;
  onOpenLeaderboard: () => void;
  onChallengeFriend: () => void;
}

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({
  result,
  stats,
  isNewPersonalBest,
  newAchievements,
  onPlayAgain,
  onGoHome,
  onOpenScoreCardModal,
  onShareWhatsApp,
  onOpenLeaderboard,
  onChallengeFriend,
}) => {
  const [copiedChallenge, setCopiedChallenge] = useState(false);

  const mainScore = result.mode === 'classic' ? result.fastestMs : result.averageMs;
  const rating = getPerformanceRating(mainScore);

  // Trigger celebration confetti for new best or elite score
  useEffect(() => {
    if (isNewPersonalBest || mainScore < 200) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00ff66', '#a855f7', '#00f0ff', '#ffffff']
        });
      } catch {
        // safe fallback
      }
    }
  }, [isNewPersonalBest, mainScore]);

  // Comparison with previous attempt in the same mode
  const previousSameModeGames = stats.history.filter(
    (h) => h.mode === result.mode && h.id !== result.id
  );
  const previousGame = previousSameModeGames.length > 0 ? previousSameModeGames[0] : null;
  const previousScore = previousGame 
    ? (previousGame.mode === 'classic' ? previousGame.fastestMs : previousGame.averageMs) 
    : null;
  const diffFromPrevious = previousScore !== null ? mainScore - previousScore : null;

  // Personal Best benchmark for this mode
  const personalBestScore = result.mode === 'classic' 
    ? stats.classicBest 
    : result.mode === 'five_rounds' 
    ? stats.fiveRoundsBestAvg 
    : stats.enduranceBestAvg;

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-4 flex flex-col items-center select-none animate-fadeIn">
      {/* New Personal Best Banner */}
      {isNewPersonalBest && (
        <div className="mb-4 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold flex items-center gap-2 glow-purple animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>NEW ALL-TIME PERSONAL BEST!</span>
          <Award className="w-4 h-4 text-amber-400" />
        </div>
      )}

      {/* Main Score Hero Card */}
      <div className="w-full p-6 sm:p-8 rounded-3xl bg-neutral-900/80 border border-neutral-800 text-center relative overflow-hidden mb-6">
        {/* Glow backdrop matching tier */}
        <div
          className="absolute -top-24 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full blur-3xl opacity-20 pointer-events-none"
          style={{ backgroundColor: rating.color }}
        />

        <div className="relative z-10 flex flex-col items-center">
          <span className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2">
            {result.mode === 'classic' ? 'REACTION TIME' : 'AVERAGE SPEED'}
          </span>

          {/* Huge milliseconds display */}
          <div className="flex items-baseline justify-center gap-2 mb-2">
            <span className="text-7xl sm:text-9xl font-black font-mono tracking-tight text-white">
              {mainScore}
            </span>
            <span className="text-2xl sm:text-4xl font-bold font-mono text-emerald-400">
              ms
            </span>
          </div>

          {/* Performance Tier Badge */}
          <div
            className="px-4 py-1.5 rounded-lg border font-mono font-bold text-xs sm:text-sm uppercase tracking-wider mb-3 flex items-center gap-2"
            style={{
              color: rating.color,
              borderColor: `${rating.color}50`,
              backgroundColor: `${rating.color}15`,
            }}
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>{rating.label} · {rating.percentile}</span>
          </div>

          <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto mb-6">
            {rating.description}
          </p>

          {/* Comparison with previous attempts */}
          <div className="w-full max-w-md py-2.5 px-4 rounded-xl bg-neutral-950/70 border border-neutral-800/80 flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Previous Attempt:</span>
            {previousScore !== null && diffFromPrevious !== null ? (
              <div className="flex items-center gap-1.5 font-bold">
                <span className="text-white">{previousScore} ms</span>
                {diffFromPrevious < 0 ? (
                  <span className="text-emerald-400 flex items-center">
                    <ArrowDownRight className="w-3.5 h-3.5" />
                    <span>{Math.abs(diffFromPrevious)}ms faster</span>
                  </span>
                ) : diffFromPrevious > 0 ? (
                  <span className="text-rose-400 flex items-center">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+{diffFromPrevious}ms slower</span>
                  </span>
                ) : (
                  <span className="text-neutral-400">Identical</span>
                )}
              </div>
            ) : (
              <span className="text-neutral-500">First recorded run in this mode</span>
            )}
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 font-mono">
        {/* Fastest */}
        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-center">
          <span className="text-[11px] text-neutral-400 block mb-0.5">FASTEST</span>
          <span className="text-xl font-bold text-emerald-400">{result.fastestMs} ms</span>
        </div>

        {/* Slowest */}
        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-center">
          <span className="text-[11px] text-neutral-400 block mb-0.5">SLOWEST</span>
          <span className="text-xl font-bold text-rose-400">{result.slowestMs} ms</span>
        </div>

        {/* Personal Best */}
        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-center">
          <span className="text-[11px] text-neutral-400 block mb-0.5">PERSONAL BEST</span>
          <span className="text-xl font-bold text-amber-400">
            {personalBestScore ? `${personalBestScore} ms` : '---'}
          </span>
        </div>

        {/* False Starts */}
        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 text-center">
          <span className="text-[11px] text-neutral-400 block mb-0.5">FALSE STARTS</span>
          <span className={`text-xl font-bold ${result.falseStarts > 0 ? 'text-rose-400' : 'text-neutral-300'}`}>
            {result.falseStarts}
          </span>
        </div>
      </div>

      {/* Multi-Round Breakdown (for 5-round and endurance modes) */}
      {result.attempts.length > 1 && (
        <div className="w-full p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 mb-6 font-mono">
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-3">
            <span className="font-bold text-white uppercase">Round Breakdown</span>
            <span>{result.attempts.length} attempts completed</span>
          </div>

          <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
            {result.attempts.map((ms, index) => {
              const isFastest = ms === result.fastestMs;
              const isSlowest = ms === result.slowestMs;
              return (
                <div
                  key={index}
                  className={`p-2 rounded-lg text-center border text-xs ${
                    isFastest
                      ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 font-bold'
                      : isSlowest
                      ? 'bg-rose-950/60 border-rose-500/50 text-rose-300 font-bold'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-300'
                  }`}
                >
                  <div className="text-[10px] text-neutral-400 mb-0.5">R{index + 1}</div>
                  <div className="text-xs">{ms}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Achievement Unlocked Notification */}
      {newAchievements.length > 0 && (
        <div className="w-full mb-6 p-4 rounded-xl bg-purple-950/50 border border-purple-500/40 glow-purple flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-purple-500/20 border border-purple-400 flex items-center justify-center text-xl shrink-0">
            🏆
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase tracking-wider text-purple-300 font-bold">
              Achievement Unlocked!
            </span>
            <p className="text-sm font-bold text-white">
              You unlocked new reflex milestones. Check your badges on the leaderboard!
            </p>
          </div>
        </div>
      )}

      {/* Primary Actions Grid */}
      <div className="w-full flex flex-col sm:flex-row gap-3 mb-4">
        {/* Play Again */}
        <button
          onClick={onPlayAgain}
          className="flex-1 py-3.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,255,102,0.3)] hover:scale-[1.02]"
        >
          <RotateCcw className="w-4 h-4 stroke-[2.5]" />
          <span>Play Again</span>
        </button>

        {/* Download Score Card (Direct 1-Click PNG Download) */}
        <button
          onClick={onOpenScoreCardModal}
          className="flex-1 py-3.5 px-6 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:scale-[1.02]"
          title="Download official high-resolution PNG score card"
        >
          <Download className="w-4 h-4 stroke-[2.5]" />
          <span>Download Score Card</span>
        </button>
      </div>

      {/* Secondary Actions Row */}
      <div className="w-full flex flex-wrap items-center justify-center gap-2 text-xs font-semibold">
        {/* WhatsApp Share */}
        <button
          onClick={onShareWhatsApp}
          className="px-4 py-2.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-600/40 text-emerald-300 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <MessageCircle className="w-4 h-4 text-emerald-400" />
          <span>Share on WhatsApp</span>
        </button>

        {/* Challenge Friends */}
        <button
          onClick={() => {
            onChallengeFriend();
            setCopiedChallenge(true);
            setTimeout(() => setCopiedChallenge(false), 2500);
          }}
          className="px-4 py-2.5 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 border border-purple-600/40 text-purple-300 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Zap className="w-4 h-4 text-purple-400" />
          <span>{copiedChallenge ? 'Challenge Link Copied! ✓' : 'Challenge Friends'}</span>
        </button>

        {/* View Global Leaderboard */}
        <button
          onClick={onOpenLeaderboard}
          className="px-4 py-2.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/60 text-neutral-300 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Leaderboard</span>
        </button>

        {/* Back to Home */}
        <button
          onClick={onGoHome}
          className="px-4 py-2.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/60 text-neutral-400 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>Menu</span>
        </button>
      </div>
    </div>
  );
};
