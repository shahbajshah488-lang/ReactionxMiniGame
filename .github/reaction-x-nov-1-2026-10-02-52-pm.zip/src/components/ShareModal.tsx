import React, { useState, useEffect } from 'react';
import { X, Download, Copy, MessageCircle, Check, Sparkles } from 'lucide-react';
import { GameResult } from '../types/game';
import { generateScoreCardBlob, downloadScoreCard, generateWhatsAppShareText } from '../utils/shareCard';

interface ShareModalProps {
  isOpen: boolean;
  result: GameResult | null;
  nickname: string;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  result,
  nickname,
  onClose,
}) => {
  const [blob, setBlob] = useState<Blob | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedImage, setCopiedImage] = useState(false);

  useEffect(() => {
    if (isOpen && result) {
      let isMounted = true;
      generateScoreCardBlob(result, nickname).then((generatedBlob) => {
        if (!isMounted) return;
        setBlob(generatedBlob);
        if (generatedBlob) {
          const url = URL.createObjectURL(generatedBlob);
          setImageUrl(url);
        }
      });
      return () => {
        isMounted = false;
      };
    } else {
      if (imageUrl) {
        URL.revokeObjectURL(imageUrl);
        setImageUrl(null);
      }
      setBlob(null);
    }
  }, [isOpen, result, nickname]);

  if (!isOpen || !result) return null;

  const mainScore = result.mode === 'classic' ? result.fastestMs : result.averageMs;

  const handleDownload = () => {
    if (blob) {
      downloadScoreCard(blob, mainScore);
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}?challenger=${mainScore}&name=${encodeURIComponent(nickname)}&mode=${result.mode}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    });
  };

  const handleCopyImage = async () => {
    if (blob && navigator.clipboard && 'write' in navigator.clipboard) {
      try {
        await navigator.clipboard.write([
          new ClipboardItem({ 'image/png': blob })
        ]);
        setCopiedImage(true);
        setTimeout(() => setCopiedImage(false), 2500);
      } catch {
        // Fallback to copy link
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsApp = () => {
    const text = generateWhatsAppShareText(result, nickname);
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-xl bg-neutral-950 border border-neutral-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-display text-white">Shareable Score Card</h2>
              <p className="text-xs text-neutral-400">High-resolution branded proof of your reflex</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Image Preview */}
        <div className="p-4 sm:p-6 flex flex-col items-center">
          <div className="w-full aspect-[1200/630] rounded-xl overflow-hidden border border-neutral-700/80 bg-black flex items-center justify-center relative shadow-lg">
            {imageUrl ? (
              <img
                src={imageUrl}
                alt={`Reaction X Score Card - ${mainScore}ms`}
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="text-xs font-mono text-neutral-500 animate-pulse">
                Rendering vector score card...
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 sm:p-6 border-t border-neutral-900 bg-neutral-950/80 flex flex-col gap-2.5">
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={handleDownload}
              className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-[0_0_15px_rgba(0,255,102,0.2)]"
            >
              <Download className="w-4 h-4" />
              <span>Download PNG</span>
            </button>

            <button
              onClick={handleWhatsApp}
              className="py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-black stroke-black" />
              <span>Share to WhatsApp</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs font-mono">
            <button
              onClick={handleCopyImage}
              className="py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedImage ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedImage ? 'Card Copied!' : 'Copy Image'}</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="py-2.5 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Challenge Link'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
